// import 'package:flutter/material.dart';

final String newsCreateTitle = "Add News Post";
final String feedTitle = "News Feed";
final String defaultUserImageURL =
    "https://icon-library.net/images/user-icon-image/user-icon-image-21.jpg";
final String defaultUsername = "Anonymous";
final double dialogButtonSize = 16;

final String defaultCameraImageURL =
    "https://firebasestorage.googleapis.com/v0/b/sevaxproject4sevax.appspot.com/o/static_images%2Fimageedit_1_8210492120.png?alt=media&token=082173b7-843f-4a14-b837-e40ca32a863b";

final String defaultProjectImageURL =
    "https://firebasestorage.googleapis.com/v0/b/sevaxproject4sevax.appspot.com/o/timebanklogos%2Fproject_default.jpg?alt=media&token=a2cd81e3-c90f-4d04-ae14-6cfaa42d4e90";

final String defaultGroupImageURL =
    "https://firebasestorage.googleapis.com/v0/b/sevaxproject4sevax.appspot.com/o/timebanklogos%2Fgroup_default.jpg?alt=media&token=206f56eb-d575-4ae8-ac55-34aef5f3958a";

