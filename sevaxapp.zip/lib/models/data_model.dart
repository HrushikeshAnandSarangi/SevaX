abstract class DataModel {
  DataModel();
  DataModel.fromMap(Map<String, dynamic> map);
  Map<String, dynamic> toMap();
}
