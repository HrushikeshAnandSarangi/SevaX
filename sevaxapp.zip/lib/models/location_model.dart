
class LocationDataModel {
  String location;
  double lat;
  double lng;

  LocationDataModel(
      this.location,
      this.lat,
      this.lng);
}