import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:sevaexchange/flavor_config.dart';

import 'models.dart';
import 'package:flutter/material.dart';

class OfferModel extends DataModel {
  String id;
  String title;
  String description;
  String schedule;
  String email;
  String fullName;
  String sevaUserId;
  String associatedRequest;
  List<String> requestList;
  List<String> offerAcceptors;
  int timestamp;
  String timebankId;
  GeoFirePoint location;
  bool acceptedOffer = false;
  String root_timebank_id;

  String photoUrlImage = "";

  Color color;

  OfferModel({
    this.id,
    this.title,
    this.description,
    this.email,
    this.fullName,
    this.sevaUserId,
    this.schedule,
    this.associatedRequest,
    this.color,
    this.requestList,
    this.timestamp,
    this.timebankId,
    this.location,
  }) {
    this.root_timebank_id = FlavorConfig.values.timebankId;
  }

  OfferModel.fromMapElasticSearch(Map<String, dynamic> map) {
    if (map.containsKey('id')) {
      this.id = map['id'];
    }

    if (map.containsKey("offerAccepted")) {
      this.acceptedOffer = map['offerAccepted'];
    }

    if (map.containsKey("offerAcceptors")) {
      List<String> offerAcceptors = List.castFrom(map['offerAcceptors']);
      this.offerAcceptors = offerAcceptors;
    } else {
      this.offerAcceptors = [];
    }

    if (map.containsKey('title')) {
      this.title = map['title'];
    }

    if (map.containsKey('description')) {
      this.description = map['description'];
    }
    if (map.containsKey('email')) {
      this.email = map['email'];
    }
    if (map.containsKey('fullName')) {
      this.fullName = map['fullName'];
    }
    if (map.containsKey('sevaUserId')) {
      this.sevaUserId = map['sevaUserId'];
    }
    if (map.containsKey('associatedRequest')) {
      this.associatedRequest = map['associatedRequest'];
    }
    if (map.containsKey('schedule')) {
      this.schedule = map['schedule'];
    }
    if (map.containsKey('timestamp')) {
      this.timestamp = map['timestamp'];
    }
    if (map.containsKey('requestList')) {
      List<String> requests = List.castFrom(map['requestList']);
      this.requestList = requests;
    } else {
      this.requestList = [];
    }
    if (map.containsKey('timebankId')) {
      this.timebankId = map['timebankId'];
    }
    if (map.containsKey('location')) {
      GeoPoint geoPoint = GeoPoint(map['location']['geopoint']['_latitude'],
          map['location']['geopoint']['_longitude']);
      this.location = Geoflutterfire()
          .point(latitude: geoPoint.latitude, longitude: geoPoint.longitude);
    }
  }

  OfferModel.fromMap(Map<String, dynamic> map) {
    if (map.containsKey('id')) {
      this.id = map['id'];
    }
    if (map.containsKey("offerAccepted")) {
      this.acceptedOffer = map['offerAccepted'];
    } else {
      this.offerAcceptors = [];
    }
    if (map.containsKey('title')) {
      this.title = map['title'];
    }
    if (map.containsKey('description')) {
      this.description = map['description'];
    }
    if (map.containsKey('email')) {
      this.email = map['email'];
    }
    if (map.containsKey('fullName')) {
      this.fullName = map['fullName'];
    }
    if (map.containsKey('sevaUserId')) {
      this.sevaUserId = map['sevaUserId'];
    }
    if (map.containsKey('associatedRequest')) {
      this.associatedRequest = map['associatedRequest'];
    }
    if (map.containsKey('schedule')) {
      this.schedule = map['schedule'];
    }
    if (map.containsKey('timestamp')) {
      this.timestamp = map['timestamp'];
    }
    if (map.containsKey('requestList')) {
      List<String> requests = List.castFrom(map['requestList']);
      this.requestList = requests;
    } else {
      this.requestList = [];
    }
    if (map.containsKey("offerAcceptors")) {
      List<String> offerAcceptors = List.castFrom(map['offerAcceptors']);
      this.offerAcceptors = offerAcceptors;
    }

    if (map.containsKey('timebankId')) {
      this.timebankId = map['timebankId'];
    }
    if (map.containsKey('location')) {
      // GeoPoint geoPoint = GeoPoint(map['location']['geopoint']['_latitude'], map['location']['geopoint']['_longitude']);
      GeoPoint geoPoint = map['location']['geopoint'];
      this.location = Geoflutterfire()
          .point(latitude: geoPoint.latitude, longitude: geoPoint.longitude);
    }
  }

  @override
  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};

    if (this.id != null && this.id.isNotEmpty) {
      map['id'] = this.id;
    }

    if (this.root_timebank_id != null && this.root_timebank_id.isNotEmpty) {
      map['root_timebank_id'] = this.root_timebank_id;
    }

    if (this.title != null && this.title.isNotEmpty) {
      map['title'] = this.title;
    }
    if (this.description != null && this.description.isNotEmpty) {
      map['description'] = this.description;
    }
    if (this.email != null && this.email.isNotEmpty) {
      map['email'] = this.email;
    }
    if (this.fullName != null && this.fullName.isNotEmpty) {
      map['fullName'] = this.fullName;
    }
    if (this.sevaUserId != null && this.sevaUserId.isNotEmpty) {
      map['sevaUserId'] = this.sevaUserId;
    }
    if (this.associatedRequest != null && this.associatedRequest.isNotEmpty) {
      map['assossiatedRequest'] = this.associatedRequest;
    } else {
      map['assossiatedRequest'] = null;
    }
    if (this.schedule != null && this.schedule.isNotEmpty) {
      map['schedule'] = this.schedule;
    }
    if (this.timestamp != null) {
      map['timestamp'] = this.timestamp;
    }
    if (this.requestList != null) {
      map['requestList'] = this.requestList;
    }
    if (this.timebankId != null) {
      map['timebankId'] = this.timebankId;
    }
    if (this.location != null) {
      map['location'] = this.location.data;
    }
    if (this.offerAcceptors != null) {
      map['offerAcceptors'] = this.offerAcceptors;
    } else {
      map['offerAcceptors'] = [];
    }

    return map;
  }

  @override
  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {};

    if (this.id != null && this.id.isNotEmpty) {
      map['id'] = this.id;
    }
    if (this.title != null && this.title.isNotEmpty) {
      map['title'] = this.title;
    }
    if (this.description != null && this.description.isNotEmpty) {
      map['description'] = this.description;
    }
    if (this.email != null && this.email.isNotEmpty) {
      map['email'] = this.email;
    }
    if (this.fullName != null && this.fullName.isNotEmpty) {
      map['fullName'] = this.fullName;
    }
    if (this.sevaUserId != null && this.sevaUserId.isNotEmpty) {
      map['sevaUserId'] = this.sevaUserId;
    }
    if (this.associatedRequest != null && this.associatedRequest.isNotEmpty) {
      map['assossiatedRequest'] = this.associatedRequest;
    } else {
      map['assossiatedRequest'] = null;
    }
    if (this.schedule != null && this.schedule.isNotEmpty) {
      map['schedule'] = this.schedule;
    }
    if (this.timestamp != null) {
      map['timestamp'] = this.timestamp;
    }
    if (this.requestList != null) {
      map['requestList'] = this.requestList;
    }
    if (this.timebankId != null) {
      map['timebankId'] = this.timebankId;
    }
    if (this.location != null) {
      map['location'] = this.location.data;
    }

    return map;
  }
}
