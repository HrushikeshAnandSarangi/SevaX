import 'package:flutter/material.dart';

ThemeData sevaTheme = new ThemeData(
  appBarTheme: AppBarTheme(
    brightness: Brightness.light,
    color: Colors.white,
    elevation: 1,
  ),
  brightness: Brightness.light,
  primarySwatch: Colors.red,
  primaryColor: Colors.red[900],
  accentColor: Colors.blue,
  indicatorColor: Colors.white,
  primaryColorBrightness: Brightness.light,
  accentColorBrightness: Brightness.light,
  fontFamily: 'Montserrat',
  splashColor: Colors.grey,
);
