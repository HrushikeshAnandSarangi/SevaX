class ExplorePageLabels {
  static const List<String> tabContent = [
    "Feeds",
    "Requests",
    "Offers",
    "Projects",
    "Groups",
    "Members"
  ];

  static const String groupInfo =
      "Join a group to contribute place holder for users to help what groups are about.";

}
