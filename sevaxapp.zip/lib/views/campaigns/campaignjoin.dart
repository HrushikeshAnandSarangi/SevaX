import 'package:flutter/material.dart';

class CampaignJoin extends StatelessWidget {
  final String timebankID;

  CampaignJoin({Key key, this.timebankID}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('Campaign Join!'),
    );
  }
}
