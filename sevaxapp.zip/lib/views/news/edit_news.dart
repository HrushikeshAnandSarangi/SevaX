import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart';
import 'package:location/location.dart' as prefix1;
import 'package:sevaexchange/components/location_picker.dart';

import 'package:sevaexchange/components/newsimage/newsimage.dart';
import 'package:sevaexchange/main.dart' as prefix0;
import 'package:sevaexchange/models/models.dart';
import 'package:sevaexchange/utils/firestore_manager.dart' as FirestoreManager;
import 'package:sevaexchange/globals.dart' as globals;
import 'package:sevaexchange/flavor_config.dart';
import 'package:sevaexchange/utils/location_utility.dart';
import 'package:sevaexchange/views/core.dart';

import '../../main.dart';

class NewsEdit extends StatelessWidget {
  final GlobalKey<NewsEditFormState> _formState = GlobalKey();
  final String timebankId;
  NewsModel newsModel;
  NewsEdit({this.timebankId,this.newsModel});
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        globals.newsImageURL = null;
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Theme.of(context).primaryColor,
          title: Text(
            "Update feed",
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: false,
          actions: <Widget>[
            //  OutlineButton(
            //         //color: Colors.indigo,
            //         onPressed: () {
            //           // Validate will return true if the form is valid, or false if
            //           // the form is invalid.

            //           if (_formState.currentState.formKey.currentState.validate()) {
            //             // If the form is valid, we want to show a Snackbar
            //             Scaffold.of(context).showSnackBar(
            //                 SnackBar(content: Text('Creating Post')));
            //             _formState.currentState.writeToDB();
            //           }
            //         },
            //         highlightColor: Colors.white,
            //         child: Text(
            //           'Save',
            //           style: TextStyle(color: Colors.white),
            //         ),
            //       ),
          ],
        ),
        body: NewsEditForm(
          timebankId: timebankId,
          newsModel: newsModel,
        ),
      ),
    );
  }
}

// Create a Form Widget
class NewsEditForm extends StatefulWidget {
  final String timebankId;
  NewsModel newsModel;
  NewsEditForm({Key key, this.timebankId,this.newsModel}) : super(key: key);
  @override
  NewsEditFormState createState() {
    return NewsEditFormState();
  }
}

// Create a corresponding State class. This class will hold the data related to
// the form.
class NewsEditFormState extends State<NewsEditForm> {
  // Create a global key that will uniquely identify the Form widget and allow
  // us to validate the form
  //
  // Note: This is a GlobalKey<FormState>, not a GlobalKey<NewsCreateFormState>!
  final formKey = GlobalKey<FormState>();
  String imageUrl;
  NewsModel newsObject = NewsModel();
  TextStyle textStyle;

  List<DataModel> dataList = [];
  DataModel selectedEntity;
  GeoFirePoint location;
  String selectedAddress;

//  Future<void> writeToDB() async {
//    int timestamp = DateTime.now().millisecondsSinceEpoch;
//
//    newsObject.id = '${SevaCore.of(context).loggedInUser.email}*$timestamp';
//    newsObject.email = SevaCore.of(context).loggedInUser.email;
//    newsObject.fullName = SevaCore.of(context).loggedInUser.fullname;
//    newsObject.sevaUserId = SevaCore.of(context).loggedInUser.sevaUserID;
//    newsObject.newsImageUrl = globals.newsImageURL ?? '';
//    newsObject.postTimestamp = timestamp;
//    newsObject.location = location;
//
////    EntityModel entityModel = _getSelectedEntityModel;
//    EntityModel entityModel = EntityModel(
//      entityId: widget.timebankId,
//      //entityName: FlavorConfig.timebankName,
//      entityType: EntityType.timebank,
//    );
//
//    newsObject.entity = entityModel;
//
//    await FirestoreManager.createNews(newsObject: newsObject);
//    globals.newsImageURL = null;
//    Navigator.pop(context);
//  }

//  EntityModel get _getSelectedEntityModel {
//    if (this.selectedEntity.runtimeType == TimebankModel) {
//      TimebankModel model = this.selectedEntity;
//      return EntityModel(
//        entityId: model.id,
//        entityName: model.name,
//        entityType: EntityType.timebank,
//      );
//    } else if (this.selectedEntity.runtimeType == CampaignModel) {
//      CampaignModel model = this.selectedEntity;
//      return EntityModel(
//        entityId: model.id,
//        entityName: model.name,
//        entityType: EntityType.campaign,
//      );
//    } else {
//      return EntityModel(entityType: EntityType.general);
//    }
//  }
  //news
  Future<void> updateNews({
    @required NewsModel newsModel,
  }) async {

    return await Firestore.instance
        .collection('news')
        .document(newsModel.id)
        .updateData(newsModel.toMap());
  }

  @override
  void initState() {
    super.initState();

    dataList.add(EntityModel(entityType: EntityType.general));
    this.location = widget.newsModel.location;
    globals.newsImageURL = widget.newsModel.newsImageUrl;
    //this.location = widget.newsModel.location;
//    ApiManager.getTimeBanksForUser(userEmail: globals.email)
//        .then((List<TimebankModel> timeBankModelList) {
//      setState(() {
//        timeBankModelList.forEach((model) {
//          dataList.add(model);
//        });
//      });
//    });
//
//    ApiManager.getCampaignsForUser(userEmail: globals.email)
//        .then((List<CampaignModel> campaignModelList) {
//      setState(() {
//        campaignModelList.forEach((model) {
//          dataList.add(model);
//        });
//      });
//    });
  }

  @override
  void didChangeDependencies() {
    FirestoreManager.FirestoreManager.getEntityDataListStream(
      userEmail: SevaCore.of(context).loggedInUser.email,
    ).listen(
          (dataList) {
        setState(() {
          dataList.forEach((data) => this.dataList.add(data));
        });
      },
    );
    super.didChangeDependencies();
  }

  void status(){}

  @override
  Widget build(BuildContext context) {
    textStyle = Theme.of(context).textTheme.title;
    // Build a Form widget using the formKey we created above
    return Form(
        key: formKey,
        child: Container(
          // margin: EdgeInsets.all(10),
          // padding: EdgeInsets.all(10.0),
          child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      // Container(
                      //   alignment: Alignment(1.0, 0),
                      //   padding: const EdgeInsets.only(right: 10.0, bottom: 10),
                      //   child:
                      //   RaisedButton(
                      //     shape: StadiumBorder(),
                      //     color: Colors.indigoAccent,
                      //     onPressed: () {
                      //       // Validate will return true if the form is valid, or false if
                      //       // the form is invalid.

                      //       if (formKey.currentState.validate()) {
                      //         // If the form is valid, we want to show a Snackbar
                      //         Scaffold.of(context).showSnackBar(
                      //             SnackBar(content: Text('Creating Post')));
                      //         writeToDB();
                      //       }
                      //     },
                      //     child: Text(
                      //       'Save News Post',
                      //       style: TextStyle(color: Colors.white),
                      //     ),
                      //   ),
                      // ),

//              entityDropdown,

                      Padding(
                        padding: const EdgeInsets.only(top: 0),
                        child: Center(
                          child: NewsImage(),
                        ),
                      ),

                      Container(
                        padding: EdgeInsets.fromLTRB(
                            MediaQuery.of(context).size.width / 4,
                            0,
                            MediaQuery.of(context).size.width / 4,
                            0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: '+ Photo Credits',
                          ),
                          initialValue: widget.newsModel.photoCredits,
                          keyboardType: TextInputType.text,
                          textAlign: TextAlign.center,
                          onChanged: (value) {
                            widget.newsModel.photoCredits = value;
                          },
                          //style: textStyle,
                          validator: (value) {
                            // if (value.isEmpty) {
                            //   return 'Please enter some text';
                            // }
                            newsObject.photoCredits = value;
                          },
                        ),
                      ),
                      Text(""),

                      Container(
                        margin: EdgeInsets.all(20),
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(bottom: 20.0),
                              child: TextFormField(
                                initialValue: widget.newsModel.title,
                                onChanged: (value) {
                                  widget.newsModel.title = value;
                                },
                                decoration: InputDecoration(
                                  hintText: 'Your feed title',
                                  labelText: '+ Feed Title',
                                  border: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(10.0),
                                    ),
                                    borderSide: new BorderSide(
                                      color: Colors.black,
                                      width: 0.5,
                                    ),
                                  ),
                                ),
                                keyboardType: TextInputType.text,
                                //style: textStyle,
                                validator: (value) {
                                  if (value.isEmpty) {
                                    return 'Please enter the Post Title';
                                  }
                                  newsObject.title = value;
                                },
                              ),
                            ),
                            Padding(
                                padding: EdgeInsets.only(bottom: 0.0),
                                child: TextFormField(
                                  initialValue: widget.newsModel.subheading,
                                  onChanged: (value) {
                                    widget.newsModel.subheading = value;
                                  },
                                  decoration: InputDecoration(
                                    hintText: 'Your sub heading',
                                    labelText: '+ Sub Heading',
                                    border: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        const Radius.circular(10.0),
                                      ),
                                      borderSide: new BorderSide(
                                        color: Colors.black,
                                        width: 0.5,
                                      ),
                                    ),
                                  ),
                                  keyboardType: TextInputType.text,
                                  //style: textStyle,
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return 'Please enter some text';
                                    }
                                    newsObject.subheading = value;
                                  },
                                )),
                            Text(""),
                            TextFormField(
                              initialValue: widget.newsModel.description,
                              onChanged: (value) {
                                widget.newsModel.description = value;
                              },
                              decoration: InputDecoration(
                                hintText: 'Your news and any #hashtags',
                                labelText: '+ #hashtags',
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                  borderSide: new BorderSide(
                                    color: Colors.black,
                                    width: 0.5,
                                  ),
                                ),
                              ),
                              keyboardType: TextInputType.multiline,
                              //style: textStyle,
                              maxLines: null,
                              validator: (value) {
                                if (value.isEmpty) {
                                  return 'Please enter some text';
                                }
                                newsObject.description = value;
                              },
                            ),
                          ],
                        ),
                      ),

                      Text(""),
                    ],
                  ),
                  FlatButton.icon(
                    icon: Icon(Icons.add_location),
                    label: Text(
                      selectedAddress == null || selectedAddress.isEmpty
                          ? '${this._getLocation()}'
                          : selectedAddress,
                    ),
                    color: Colors.grey[200],
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute<GeoFirePoint>(
                          builder: (context) => LocationPicker(
                            selectedLocation: location,
                          ),
                        ),
                      ).then((point) {
                        if (point != null) location = point;
                        _getLocation();
                        log('ReceivedLocation: $selectedAddress');
                      });
                    },
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
                    alignment: Alignment(0, 1),
                    padding: const EdgeInsets.only(top: 10.0),
                    child: RaisedButton(
                      shape: StadiumBorder(),
                      color: Theme.of(context).accentColor,
                      onPressed: () {
                        // Validate will return true if the form is valid, or false if
                        // the form is invalid.
                        if (location != null) {
                          if (formKey.currentState.validate()) {
                            // If the form is valid, we want to show a Snackbar
                            Scaffold.of(context).showSnackBar(
                                SnackBar(content: Text('Updating Post')));
                            widget.newsModel.location = location;
                            widget.newsModel.newsImageUrl = globals.newsImageURL;
                            updateNews(newsModel: widget.newsModel);
                            globals.newsImageURL = null;
                            Navigator.pop(context);
                            //writeToDB();
                          }
                        } else {
                          Scaffold.of(context).showSnackBar(SnackBar(
                            content: Text('Location not added'),
                          ));
                        }
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(
                            Icons.attachment,
                            size: 24.0,
                            color: FlavorConfig.values.buttonTextColor,
                          ),
                          Text(' '),
                          Text(
                            'Update feed',
                            style: TextStyle(
                              color: FlavorConfig.values.buttonTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Text(sevaUserID),
                ],
              )),
        ));
  }

  Widget get entityDropdown {
    return Container(
      padding: EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<DataModel>(
        decoration: InputDecoration.collapsed(
          hintText: '+ Category',
          hintStyle: Theme.of(context).textTheme.title.copyWith(
            color: Theme.of(context).hintColor,
          ),
        ),
        validator: (value) {
          if (value == null) {
            return 'Please select a category';
          }
        },
        items: dataList.map((dataModel) {
          if (dataModel.runtimeType == EntityModel) {
            return DropdownMenuItem<DataModel>(
              child: Text('General', style: textStyle),
              value: dataModel,
            );
          } else if (dataModel.runtimeType == TimebankModel) {
            TimebankModel model = dataModel;
            return DropdownMenuItem<DataModel>(
              child: Text(
                '${model.name}',
                style: textStyle,
              ),
              value: model,
            );
          } else if (dataModel.runtimeType == CampaignModel) {
            CampaignModel model = dataModel;
            return DropdownMenuItem<DataModel>(
              child: Text(
                '${model.name}',
                style: textStyle,
              ),
              value: model,
            );
          }
          return DropdownMenuItem<DataModel>(
            child: Text(
              'Undefined',
              style: textStyle,
            ),
            value: null,
          );
        }).toList(),
        value: selectedEntity,
        onChanged: (dataModel) {
          setState(() {
            this.selectedEntity = dataModel;
          });
        },
      ),
    );
  }

  Future _getLocation() async {
    String address = await LocationUtility().getFormattedAddress(
      location.latitude,
      location.longitude,
    );
    setState(() {
      this.selectedAddress = address;
    });
  }
}
