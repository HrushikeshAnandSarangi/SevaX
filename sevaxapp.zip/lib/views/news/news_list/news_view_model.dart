import 'package:sevaexchange/base/base_view_model.dart';
import 'package:sevaexchange/models/models.dart';

class NewsViewModel extends BaseViewModel {
  Stream<List<NewsModel>> _newsStream;
}
