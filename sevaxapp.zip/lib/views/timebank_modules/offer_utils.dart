// import 'package:sevaexchange/models/models.dart';

// String getOfferTitle({OfferModel offerDataModel}) {
//   return offerDataModel.offerType == OfferType.INDIVIDUAL_OFFER
//       ? offerDataModel.individualOfferDataModel.title
//       : offerDataModel.groupOfferDataModel.classTitle;
// }

// String getOfferDescription({OfferModel offerDataModel}) {
//   return offerDataModel.offerType == OfferType.INDIVIDUAL_OFFER
//       ? offerDataModel.individualOfferDataModel.description
//       : offerDataModel.groupOfferDataModel.classDescription;
// }

// List<String> getOfferParticipants({OfferModel offerDataModel}) {
//   return offerDataModel.offerType == OfferType.INDIVIDUAL_OFFER
//       ? offerDataModel.individualOfferDataModel.offerAcceptors
//       : offerDataModel.groupOfferDataModel.signedUpMembers;
// }
