import 'package:flutter/material.dart';
import 'package:sevaexchange/views/timebanks/admin_notification_view.dart';

class TimebankNotificationsView extends StatelessWidget {
  final String timebankId;
  TimebankNotificationsView({this.timebankId});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AdminNotificationViewHolder(timebankId: timebankId),
    );
  }
}
