import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sevaexchange/models/chat_model.dart';
import 'package:sevaexchange/models/news_model.dart';
import 'package:sevaexchange/models/user_model.dart';
import 'package:sevaexchange/new_baseline/models/timebank_model.dart';
import 'package:sevaexchange/utils/data_managers/chat_data_manager.dart';
import 'package:sevaexchange/utils/data_managers/user_data_manager.dart';
import 'package:sevaexchange/utils/firestore_manager.dart' as FirestoreManager;
import 'package:sevaexchange/views/core.dart';
import 'package:sevaexchange/views/messages/chatview.dart';
import 'package:sevaexchange/views/timebanks/widgets/timebank_seva_coin.dart';

// import 'package:sevaexchange/views/core.dart';

class TimeBankAboutView extends StatefulWidget {
  final TimebankModel timebankModel;
  final String email;
  final String userId;
  TimeBankAboutView.of({this.timebankModel, this.email, this.userId});

  @override
  _TimeBankAboutViewState createState() => _TimeBankAboutViewState();
}

class _TimeBankAboutViewState extends State<TimeBankAboutView>
    with AutomaticKeepAliveClientMixin {
  bool descTextShowFlag = false;
  bool isUserJoined = false;
  String loggedInUser;
  UserModelListMoreStatus userModels;
  UserModel user;
  bool isDataLoaded = false;
  bool isAdminLoaded = false;
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    getData(); // TODO: implement initState
  }

  @override
  void getData() async {
    // print('Admin id  ${widget.timebankModel.admins[0]}');

    await FirestoreManager.getUserForId(
            sevaUserId: widget.timebankModel.admins[0])
        .then((onValue) {
      user = onValue;
      setState(() {
        isAdminLoaded = true;
      });
    });

//    if (user != null) {
//      isAdminLoaded = true;
//    }

    if (widget.timebankModel.members.contains(widget.userId)) {
      isUserJoined = true;
      userModels = await FirestoreManager
          .getUsersForAdminsCoordinatorsMembersTimebankIdTwo(
              widget.timebankModel.id, 1, widget.email);
      isDataLoaded = true;
    }

    // setState(() {});

    //  print('Time Bank${userModels.userModelList[0].photoURL}');
  }

  @override
  Widget build(BuildContext context) {
    var futures = <Future>[];
    widget.timebankModel.members.forEach((member) {
      futures.add(getUserForId(sevaUserId: member));
    });

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              child: CachedNetworkImage(
                imageUrl: widget.timebankModel.photoUrl ?? ' ',
                fit: BoxFit.cover,
                errorWidget: (context, url, error) => Container(
                    height: 80,
                    child: Center(
                      child: Text(
                        'No Image Avaialable',
                        textAlign: TextAlign.center,
                      ),
                    )),
                placeholder: (conext, url) {
                  return Center(child: CircularProgressIndicator());
                },
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0, bottom: 10, top: 10),
              child: RichText(
                text:
                    TextSpan(style: TextStyle(color: Colors.black), children: [
                  TextSpan(
                    text: 'Part of',
                    style: TextStyle(fontSize: 16, fontFamily: 'Europa'),
                  ),
                  TextSpan(
                    text: " SevaX Global Network of Timebanks.",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Europa'),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Text(
                widget.timebankModel.name ?? " ",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Europa',
                ),
              ),
            ),
            Offstage(
                offstage: !widget.timebankModel.admins
                    .contains(SevaCore.of(context).loggedInUser.sevaUserID),
                child: TimeBankSevaCoin(
                  communityId:
                      SevaCore.of(context).loggedInUser.currentCommunity,
                )),
            SizedBox(
              height: 15,
            ),
            widget.timebankModel.members.contains(
              SevaCore.of(context).loggedInUser.sevaUserID,
            )
                ? Container(
                    height: 40,
                    child: GestureDetector(
                      child: FutureBuilder(
                          future: Future.wait(futures),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return Container(
                                margin: EdgeInsets.only(left: 15),
                                child: Text("Getting volunteers..."),
                              );
                            }

                            if (widget.timebankModel.members.length == 0) {
                              return Container(
                                margin: EdgeInsets.only(left: 15),
                                child: Text("No Volunteers joined yet."),
                              );
                            }

                            List<String> memberPhotoUrlList = [];
                            for (var i = 0;
                                i < widget.timebankModel.members.length;
                                i++) {
                              UserModel userModel = snapshot.data[i];
                              if (userModel != null) {
                                userModel.photoURL != null
                                    ? memberPhotoUrlList.add(userModel.photoURL)
                                    : print("Userimage not yet set");
                              }
                            }

                            return ListView(
                              padding: EdgeInsets.only(left: 15),
                              scrollDirection: Axis.horizontal,
                              children: <Widget>[
                                ...memberPhotoUrlList.map((photoUrl) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 2.5),
                                    child: Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            fit: BoxFit.cover,
                                            image: CachedNetworkImageProvider(
                                              photoUrl ?? Icons.person,
                                            ),
                                          )),
                                    ),
                                  );
                                }).toList()
                              ],
                            );
                          }),
                    ),
                  )
                : Container(),
            isUserJoined && isDataLoaded
                ? Container(
                    height: 40,
                    child: GestureDetector(
                      onTap: () {
                        print('listview clicked');
                      },
                      child: ListView.builder(
                        padding: EdgeInsets.only(left: 20),
                        scrollDirection: Axis.horizontal,
                        itemCount: 8,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 2.5),
                            child: Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: CachedNetworkImageProvider(
                                      userModels.userModelList[index].photoURL,
                                    ),
                                  )),
                            ),
                          );
                        },
                      ),
                    ),
                  )
                : Container(),
            Padding(
              padding: const EdgeInsets.only(top: 10.0, left: 20),
              child: Text(
                widget.timebankModel.members.length.toString() +
                        ' Volunteers' ??
                    '0 Volunteers',
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text(
                widget.timebankModel.address ?? '',
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Divider(
                color: Colors.black12,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, top: 10, bottom: 10),
              child: Text(
                'About us',
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlueAccent,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 10.0, 15, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(widget.timebankModel.missionStatement,
                      style: TextStyle(
                        fontFamily: 'Europa',
                        fontSize: 16,
                        color: Colors.black,
                      ),
                      maxLines: descTextShowFlag ? null : 2,
                      textAlign: TextAlign.start),
                  InkWell(
                    onTap: () {
                      setState(() {
                        descTextShowFlag = !descTextShowFlag;
                      });
                    },
                    child: widget.timebankModel.missionStatement.length > 100
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              descTextShowFlag
                                  ? Text(
                                      "Read Less",
                                      style: TextStyle(
                                        fontFamily: 'Europa',
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.lightBlueAccent,
                                      ),
                                    )
                                  : Text(
                                      "Read More",
                                      style: TextStyle(
                                        fontFamily: 'Europa',
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.lightBlueAccent,
                                      ),
                                    )
                            ],
                          )
                        : Container(),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Divider(
                color: Colors.black12,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text(
                'Organizers',
                style: TextStyle(
                  fontFamily: 'Europa',
                  fontSize: 22,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            // print(widget.timebankModel.id);

            // burhan@uipep.com*9ecec05e-71fd-456e-9f6d-35798f41bdf5*73d0de2c-198b-4788-be64-a804700a88a4*4b75347e-56ec-4d62-8ce7-374c5cd84e5f

            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      isAdminLoaded
                          ? RichText(
                              text: TextSpan(
                                  style: TextStyle(color: Colors.black),
                                  children: [
                                    TextSpan(
                                      text: user.fullname ?? ' ',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Europa'),
                                    ),
                                    TextSpan(
                                      text: '  and Others',
                                      style: TextStyle(
                                          fontSize: 16, fontFamily: 'Europa'),
                                    ),
                                  ]),
                            )
                          : Container(
                              child: Text('Admin not Available'),
                            ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: GestureDetector(
                          onTap: () {
                            if (widget.timebankModel.admins.contains(
                                SevaCore.of(context).loggedInUser.sevaUserID)) {
                              _showAdminMessage();
                            } else {
                              startChat(widget.timebankModel.id, widget.email,
                                  context, widget.timebankModel.id);
                            }
                          },
                          child: Text(
                            'Message',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              fontFamily: 'Europa',
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.lightBlueAccent,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  isAdminLoaded
                      ? Container(
                          height: 60,
                          width: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: CachedNetworkImageProvider(user
                                        .photoURL ??
                                    'https://upload.wikimedia.org/wikipedia/commons/f/fc/No_picture_available.png')),
                          ),
                        )
                      : Container(
                          height: 60,
                          width: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: CachedNetworkImageProvider(
                                    'https://upload.wikimedia.org/wikipedia/commons/f/fc/No_picture_available.png')),
                          ),
                        ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  void _showAdminMessage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Admins cannot create message"),
          // content: new Text("Khud he ko message kyu kar rha hai?"),
          actions: <Widget>[
            new FlatButton(
              child: new Text(
                "Close",
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

var timeStamp = DateTime.now().millisecondsSinceEpoch;

void startChat(
  String email,
  String loggedUserEmail,
  BuildContext context,
  String timbebankId,
) async {
  if (email == loggedUserEmail) {
    return null;
  } else {
    List users = [email, loggedUserEmail];
    print("Listing users");
    users.sort();
    ChatModel model = ChatModel();
    model.communityId = SevaCore.of(context).loggedInUser.currentCommunity;
    model.user1 = users[0];
    model.user2 = users[1];
    model.timebankId = timbebankId;
    print("Model2" + model.user2);

    await createChat(chat: model).then(
      (_) {
//        Navigator.of(context).pop();

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChatView(
              useremail: email,
              chatModel: model,
              isFromShare: false,
              news: NewsModel(),
              isFromNewChat: IsFromNewChat(true, timeStamp),
            ),
          ),
        );
      },
    );
  }
}
