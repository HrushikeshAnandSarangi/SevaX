enum CardType {
  americanExpress,
  dinersClub,
  discover,
  jcb,
  masterCard,
  maestro,
  rupay,
  visa,
  other
}